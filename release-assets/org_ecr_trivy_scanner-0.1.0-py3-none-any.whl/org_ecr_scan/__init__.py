"""Organization ECR vulnerability scanner."""
__version__ = "0.1.0"
