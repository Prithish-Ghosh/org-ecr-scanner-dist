"""Trivy subprocess execution and short-lived ECR registry credentials."""
from __future__ import annotations

import base64
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from urllib.parse import urlparse


def require_trivy() -> str:
    binary = shutil.which("trivy")
    if not binary:
        raise RuntimeError("Trivy executable not found on PATH. Install Trivy from https://trivy.dev/docs/latest/getting-started/installation/")
    return binary


def trivy_version(binary: str) -> str:
    try:
        result = subprocess.run([binary, "--version"], capture_output=True, text=True, timeout=15)
        return (result.stdout.strip().splitlines() or ["unknown"])[0]
    except (OSError, subprocess.TimeoutExpired):
        return "unknown"


def run_scan(ecr, image_uri: str, report_json: Path, scanners: str) -> str:
    """Login with a one-use Docker config, scan ECR digest from remote (no Docker daemon)."""
    binary = require_trivy()
    token_response = ecr.get_authorization_token()
    auths = token_response.get("authorizationData", [])
    registry = image_uri.split("/", 1)[0]
    chosen = None
    for auth in auths:
        endpoint_host = urlparse(auth.get("proxyEndpoint", "")).netloc
        if endpoint_host == registry:
            chosen = auth
            break
    if not chosen:
        raise RuntimeError(f"ECR did not return a login token for registry {registry}")
    decoded = base64.b64decode(chosen["authorizationToken"]).decode("utf-8")
    username, sep, password = decoded.partition(":")
    if not sep or not username or not password:
        raise RuntimeError("Invalid ECR authorization token response")

    with tempfile.TemporaryDirectory(prefix="org-ecr-trivy-") as docker_config:
        env = os.environ.copy()
        env["DOCKER_CONFIG"] = docker_config
        login = subprocess.run(
            [binary, "registry", "login", "--username", username, "--password-stdin", registry],
            input=password, capture_output=True, text=True, env=env,
        )
        if login.returncode != 0:
            raise RuntimeError("Trivy registry authentication failed: " + login.stderr.strip()[-1200:])
        command = [
            binary, "image", "--image-src", "remote", "--scanners", scanners,
            "--format", "json", "--exit-code", "0", "--output", str(report_json),
            image_uri,
        ]
        print("Scanning registry image with Trivy (first run may download its vulnerability database)...", flush=True)
        result = subprocess.run(command, env=env)
        if result.returncode != 0:
            raise RuntimeError(f"Trivy exited with code {result.returncode}. Check the output above; no clean report will be claimed.")
        if not report_json.is_file():
            raise RuntimeError("Trivy returned success but did not create a JSON report.")
        try:
            with report_json.open(encoding="utf-8") as fh:
                data = json.load(fh)
            if not isinstance(data, dict) or (data.get("Results") is not None and not isinstance(data.get("Results"), list)) or not ("SchemaVersion" in data or "Results" in data):
                raise ValueError("Missing valid Trivy schema/results")
        except (ValueError, OSError) as exc:
            raise RuntimeError(f"Trivy returned an invalid JSON report: {exc}") from exc
    return trivy_version(binary)
