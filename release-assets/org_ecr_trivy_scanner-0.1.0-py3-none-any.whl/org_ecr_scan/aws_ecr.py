"""AWS ECR listing and selecting immutable image versions."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

import boto3


@dataclass(frozen=True)
class ImageChoice:
    tag: str
    digest: str
    pushed_at: datetime | None
    size_bytes: int


def session_for(profile: str | None, region: str | None):
    kwargs = {}
    if profile:
        kwargs["profile_name"] = profile
    if region:
        kwargs["region_name"] = region
    return boto3.Session(**kwargs)


def available_profiles() -> list[str]:
    profiles = boto3.Session().available_profiles
    return ["default"] + sorted(p for p in profiles if p != "default")


def list_repositories(ecr) -> list[dict[str, Any]]:
    result = []
    for page in ecr.get_paginator("describe_repositories").paginate():
        result.extend(page.get("repositories", []))
    return sorted(result, key=lambda r: r.get("repositoryName", "").lower())


def get_repository(ecr, name: str) -> dict[str, Any]:
    repos = ecr.describe_repositories(repositoryNames=[name])["repositories"]
    if not repos:
        raise ValueError(f"Repository not found: {name}")
    return repos[0]


def list_recent_images(ecr, name: str) -> list[ImageChoice]:
    """Get all tagged image digests, then show each tag alongside its digest."""
    rows = []
    paginator = ecr.get_paginator("describe_images")
    for page in paginator.paginate(repositoryName=name, filter={"tagStatus": "TAGGED"}):
        for details in page.get("imageDetails", []):
            if not details.get("imageDigest"):
                continue
            for tag in details.get("imageTags") or []:
                rows.append(ImageChoice(
                    tag=tag,
                    digest=details["imageDigest"],
                    pushed_at=details.get("imagePushedAt"),
                    size_bytes=details.get("imageSizeInBytes", 0),
                ))
    rows.sort(key=lambda i: (i.pushed_at.timestamp() if i.pushed_at else 0, i.tag), reverse=True)
    return rows


def resolve_tag(ecr, repository_name: str, tag: str) -> ImageChoice:
    """Resolve tag at scan start to avoid mutable-tag race conditions."""
    details = ecr.describe_images(
        repositoryName=repository_name, imageIds=[{"imageTag": tag}]
    )["imageDetails"][0]
    return ImageChoice(tag=tag, digest=details["imageDigest"],
                       pushed_at=details.get("imagePushedAt"),
                       size_bytes=details.get("imageSizeInBytes", 0))
