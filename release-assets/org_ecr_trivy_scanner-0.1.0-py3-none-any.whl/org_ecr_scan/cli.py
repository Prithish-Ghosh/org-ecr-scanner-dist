"""Interactive and CI friendly command line entry point."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import shutil
import sys

from botocore.exceptions import BotoCoreError, ClientError, NoCredentialsError, ProfileNotFound

from . import __version__
from .aws_ecr import available_profiles, get_repository, list_recent_images, list_repositories, resolve_tag, session_for
from .reporter import generate_pdf
from .trivy_runner import run_scan


def ask_choice(question: str, items: list[str], show_max: int = 30, manual_allowed: bool = False) -> str:
    if not items and not manual_allowed:
        raise RuntimeError(f"No options available for {question}")
    print(f"\n{question}")
    for i, label in enumerate(items[:show_max], start=1):
        print(f"  {i:>2}. {label}")
    if len(items) > show_max:
        print(f"  ... {len(items) - show_max} more; enter an exact name to select a hidden item")
    while True:
        response = input("Enter a number or name [1]: ").strip()
        if not response and items:
            return items[0]
        if response.isdigit() and 1 <= int(response) <= len(items):
            return items[int(response) - 1]
        if response in items or (manual_allowed and response):
            return response
        print("Not a valid choice. Please enter a listed number or a full name.")


def slug(s: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_.-]", "_", s)[:90].strip("._-") or "unknown"


def output_folder(parent: Path, repository: str, tag: str) -> Path:
    suffix = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    p = parent / f"{slug(repository)}_{slug(tag)}_{suffix}"
    p.mkdir(parents=True, exist_ok=False)
    return p


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="scan",
        description="Scan private AWS ECR images using Trivy and generate polished PDF + JSON reports.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--profile", help="Named AWS CLI/SSO profile (omit to select interactively)")
    p.add_argument("--region", help="ECR AWS Region, e.g. ap-south-1")
    p.add_argument("--repository", help="ECR repository name, e.g. servicestation/servicestation-dev")
    image = p.add_mutually_exclusive_group()
    image.add_argument("--tag", help="Image tag; resolved to an immutable digest before scanning")
    image.add_argument("--latest", action="store_true", help="Select a tag on the most recently pushed image")
    p.add_argument("--output-dir", type=Path, default=Path.cwd() / "scan-reports", help="Directory for generated report subfolders")
    p.add_argument("--scanners", choices=["vuln", "vuln,secret"], default="vuln", help="Trivy scanners to enable")
    p.add_argument("--fail-on", choices=["none", "CRITICAL", "HIGH", "MEDIUM", "LOW"], default="none",
                   help="CI policy: exit 2 after writing reports if a finding meets/exceeds severity")
    p.add_argument("--non-interactive", action="store_true", help="Never ask questions (CI mode)")
    p.add_argument("--from-json", type=Path, help="Generate PDF from an existing Trivy JSON (offline, no AWS or Trivy required)")
    p.add_argument("--image", help="Image name metadata for --from-json mode")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return p


def policy_failed(counts: dict[str, int], fail_on: str) -> bool:
    if fail_on == "none":
        return False
    order = ["CRITICAL", "HIGH", "MEDIUM", "LOW"]
    return any(counts.get(key, 0) > 0 for key in order[:order.index(fail_on) + 1])


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        print("\nORG ECR TRIVY SCANNER  |  Secure image assessment\n")
        if args.from_json:
            source = args.from_json.expanduser().resolve()
            with source.open("r", encoding="utf-8") as fh:
                data = json.load(fh)
            if not isinstance(data, dict) or (data.get("Results") is not None and not isinstance(data.get("Results"), list)) or not ("SchemaVersion" in data or "Results" in data):
                raise ValueError("Expected a Trivy JSON document with a Results list or valid schema")
            image = args.image or data.get("ArtifactName", "offline-scan")
            tag = "offline"
            folder = output_folder(args.output_dir, image, tag)
            target_json = folder / "trivy-results.json"
            shutil.copyfile(source, target_json) if source != target_json.resolve() else None
            meta = {"image_uri": image, "repository": image, "tag": "offline JSON import",
                    "profile": "offline", "region": "N/A", "account_id": "N/A",
                    "digest": data.get("Metadata", {}).get("ImageID", "not provided"),
                    "trivy_version": "imported scan (version not verified)",
                    "scanners": "from existing JSON",
                    "scanned_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
        else:
            interactive = not args.non_interactive and sys.stdin.isatty()
            profile = args.profile
            if interactive and not profile:
                profile = ask_choice("Choose an AWS profile", available_profiles())
            if args.non_interactive and (not args.repository or (not args.tag and not args.latest)):
                raise ValueError("CI mode requires --repository plus --tag or --latest")
            base_session = session_for(profile, args.region)
            region = args.region or base_session.region_name
            if not region and interactive:
                region = input("AWS ECR region (e.g. ap-south-1): ").strip()
            if not region:
                raise ValueError("No AWS region detected. Supply --region or configure region in the AWS profile")
            session = session_for(profile, region)
            sts = session.client("sts")
            account_id = sts.get_caller_identity()["Account"]
            print(f"AWS Account: {account_id} | Profile: {profile or 'default'} | Region: {region}")
            ecr = session.client("ecr")
            repo_name = args.repository
            if not repo_name:
                if not interactive:
                    raise ValueError("Supply --repository in non-interactive mode")
                repositories = list_repositories(ecr)
                repo_name = ask_choice("Choose an ECR repository", [r["repositoryName"] for r in repositories])
            repository = get_repository(ecr, repo_name)
            if str(repository.get("registryId")) != str(account_id):
                raise RuntimeError("Current version supports the selected AWS profile's own registry only")
            recent = None
            if args.latest or (not args.tag and interactive):
                recent = list_recent_images(ecr, repo_name)
                if not recent:
                    raise ValueError("Repository has no tagged active images")
            if args.tag:
                requested_tag = args.tag
            elif args.latest:
                requested_tag = recent[0].tag
            elif interactive:
                top_tags = [f"{i.tag} | pushed {i.pushed_at:%Y-%m-%d %H:%M UTC}" if i.pushed_at else i.tag
                            for i in recent]
                chosen = ask_choice("Recent ECR image tags (newest images first)", top_tags, show_max=20,
                                    manual_allowed=True)
                requested_tag = recent[top_tags.index(chosen)].tag if chosen in top_tags else chosen
            else:
                raise ValueError("Specify --tag or --latest")
            selected = resolve_tag(ecr, repo_name, requested_tag)
            image_uri = f"{repository['repositoryUri']}@{selected.digest}"
            print(f"Selected tag: {selected.tag} | Pushed: {selected.pushed_at} | Digest: {selected.digest}")
            folder = output_folder(args.output_dir, repo_name, requested_tag)
            target_json = folder / "trivy-results.json"
            trivy_version = run_scan(ecr, image_uri, target_json, args.scanners)
            with target_json.open("r", encoding="utf-8") as fh:
                data = json.load(fh)
            meta = {"account_id": account_id, "profile": profile or "default",
                    "region": region, "repository": repo_name,
                    "tag": selected.tag, "digest": selected.digest,
                    "image_uri": image_uri, "trivy_version": trivy_version,
                    "scanners": args.scanners,
                    "scanned_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}

        destination = folder / "vulnerability-report.pdf"
        result = generate_pdf(data, destination, meta)
        (folder / "scan-metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        print("\nScan completed. Reports:")
        print("  PDF: ", destination.resolve())
        print("  JSON:", target_json.resolve())
        print("  Metadata:", (folder / "scan-metadata.json").resolve())
        print("  Findings:", ", ".join(f"{s}={v}" for s, v in result["counts"].items()))
        if result["secrets"]:
            print(f"  Secret detections: {result['secrets']} (values redacted in PDF)")
        if policy_failed(result["counts"], args.fail_on):
            print(f"CI gate FAILED: severity threshold {args.fail_on} reached. Reports remain available.")
            return 2
        return 0
    except (ClientError, BotoCoreError, NoCredentialsError, ProfileNotFound) as exc:
        print(f"AWS error: {exc}\nCheck selected profile, IAM permissions, region, and SSO status (aws sso login --profile NAME).", file=sys.stderr)
        return 1
    except (ValueError, RuntimeError, OSError, KeyboardInterrupt, json.JSONDecodeError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
