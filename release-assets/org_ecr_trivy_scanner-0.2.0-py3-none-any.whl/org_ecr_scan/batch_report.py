"""Generate aggregate security overview PDF and concatenate individual reports."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, LongTable, TableStyle
from pypdf import PdfReader, PdfWriter

from .reporter import safe, NAVY, LIGHT, TEAL, WHITE, SEVERITIES, SeverityBars


def generate_batch_pdf(rows: list[dict], destination: Path) -> None:
    """Append full findings for every successful repository after a batch summary."""
    good = [r for r in rows if r.get("status") == "success"]
    if not good:
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    cover = destination.parent / "_batch_overview.pdf"
    styles = getSampleStyleSheet()
    title = ParagraphStyle("batchtitle", parent=styles["Heading1"], fontSize=24, leading=30, textColor=NAVY, spaceAfter=10)
    desc = ParagraphStyle("batchdesc", parent=styles["BodyText"], fontSize=10, leading=15)
    cell = ParagraphStyle("batchcell", parent=styles["BodyText"], fontSize=8, leading=11)
    header = ParagraphStyle("batchheader", parent=cell, textColor=WHITE, fontName="Helvetica-Bold")
    total = Counter()
    for r in good:
        total.update(r["counts"])
    w, _ = A4
    width = w - 36 * mm
    story = [
        Paragraph("Container Security — Batch Assessment", title),
        Paragraph("AWS ECR / Oracle OCIR  |  Consolidated Scan Results", desc),
        Spacer(1, 8),
        Paragraph(f"Generated (UTC): {datetime.now(timezone.utc).isoformat(timespec='seconds')}", desc),
        Paragraph(f"Repositories selected: {len(rows)}   |   Successful: {len(good)}   |   Failed: {len(rows)-len(good)}", desc),
        Spacer(1, 10), Paragraph("Overall severity distribution", styles["Heading2"]),
        SeverityBars(width, total), Spacer(1, 18),
        Paragraph("Repository breakdown", styles["Heading2"]),
    ]
    table_rows = [[Paragraph(x, header) for x in ["Cloud / Repository", "Tag", "Critical", "High", "Medium", "Low", "Result"]]]
    for r in rows:
        cs = r.get("counts", {})
        table_rows.append([
            Paragraph(safe(f"{r['provider'].upper()} / {r['repository']}"), cell),
            Paragraph(safe(r.get("tag", "-")), cell),
            *[Paragraph(str(cs.get(severity, 0)), cell) for severity in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]],
            Paragraph(safe(r["status"]), cell),
        ])
    t = LongTable(table_rows, colWidths=[width*.33,width*.16,width*.09,width*.09,width*.09,width*.08,width*.16], repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0,0),(-1,0), NAVY),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[WHITE,LIGHT]),
        ("VALIGN", (0,0),(-1,-1), "TOP"),
        ("TOPPADDING",(0,0),(-1,-1),7), ("BOTTOMPADDING",(0,0),(-1,-1),7),
        ("LEFTPADDING",(0,0),(-1,-1),6), ("RIGHTPADDING",(0,0),(-1,-1),6),
    ]))
    story.append(t)
    story.append(Spacer(1,12))
    story.append(Paragraph("The following pages contain full individual PDF reports for each successfully scanned image. Counts represent occurrences, not unique CVEs.", desc))
    SimpleDocTemplate(str(cover), pagesize=A4, leftMargin=18*mm, rightMargin=18*mm,
                      topMargin=20*mm, bottomMargin=22*mm).build(story)
    try:
        writer = PdfWriter()
        writer.append(str(cover))
        for row in good:
            writer.append(row["pdf"])
        with destination.open("wb") as fp:
            writer.write(fp)
        writer.close()
    finally:
        cover.unlink(missing_ok=True)
