"""OCI Container Registry discovery via the OCI Python SDK.

The OCI API signing key is used only for metadata discovery. The registry itself
requires a separate OCI Auth Token to pull private images.
"""
from __future__ import annotations

import configparser
from dataclasses import dataclass
from datetime import datetime, timezone
import os
from pathlib import Path

from .aws_ecr import ImageChoice


def _oci():
    try:
        import oci
    except ImportError as exc:
        raise RuntimeError("OCI SDK missing: reinstall with pipx upgrade org-ecr-trivy-scanner or pip install oci") from exc
    return oci


def profiles() -> list[str]:
    path = Path(os.environ.get("OCI_CONFIG_FILE", "~/.oci/config")).expanduser()
    p = configparser.ConfigParser(interpolation=None)
    p.read(path)
    return ["DEFAULT"] + sorted(k for k in p.sections() if k != "DEFAULT")


def client_for(profile: str = "DEFAULT", region: str | None = None):
    oci = _oci()
    config = oci.config.from_file(profile_name=profile)
    if region:
        config["region"] = region
    return oci.artifacts.ArtifactsClient(config), config


def registry_namespace(config: dict) -> str:
    oci = _oci()
    client = oci.object_storage.ObjectStorageClient(config)
    return client.get_namespace().data


def _all_pages(method, **params) -> list:
    """Collect OCI collection.items; properly follow opc-next-page tokens."""
    results = []
    page = None
    while True:
        if page:
            params["page"] = page
        response = method(**params)
        payload = response.data
        results.extend(getattr(payload, "items", payload if isinstance(payload, list) else []))
        page = response.headers.get("opc-next-page") if response.headers else None
        if not page:
            break
    return results


def list_repositories(client, compartment_id: str, subtree: bool = False) -> list:
    options = {"compartment_id": compartment_id, "lifecycle_state": "AVAILABLE"}
    if subtree:
        options["compartment_id_in_subtree"] = True
    repositories = _all_pages(client.list_container_repositories, **options)
    return sorted(repositories, key=lambda r: r.display_name.lower())


def list_recent_images(client, repo, limit: int = 30) -> list[ImageChoice]:
    """Return tagged versions, including extra tags attached to a single digest.

    OCI image summaries expose only the newest version. Fetch per-image details to
    enumerate every tag, capped to `limit` most-recent image digests for interactive use.
    A manually entered tag is resolved independently and does not have this cap.
    """
    summaries = _all_pages(
        client.list_container_images,
        compartment_id=repo.compartment_id, repository_id=repo.id,
        lifecycle_state="AVAILABLE", sort_by="TIMECREATED", sort_order="DESC",
    )
    rows = []
    seen = set()
    for item in summaries[:limit]:
        # A single digest can have multiple version tags. The detail API exposes these.
        details = client.get_container_image(item.id).data
        versions = getattr(details, "versions", None) or []
        if not versions and item.version:
            versions = [item]
        for version in versions:
            tag = getattr(version, "version", None)
            digest = getattr(item, "digest", None)
            if not tag or not digest or (tag, digest) in seen:
                continue
            seen.add((tag, digest))
            rows.append(ImageChoice(
                tag=tag, digest=digest,
                pushed_at=getattr(version, "time_created", None) or item.time_created,
                size_bytes=getattr(details, "layers_size_in_bytes", 0) or 0,
            ))
    rows.sort(key=lambda i: (_timestamp(i.pushed_at), i.tag), reverse=True)
    return rows


def _timestamp(value: datetime | None) -> float:
    if not value:
        return 0
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.timestamp()


def resolve_tag(client, repo, tag: str) -> ImageChoice:
    """Use API exact version matching, then pin by immutable digest."""
    summaries = _all_pages(
        client.list_container_images,
        compartment_id=repo.compartment_id, repository_id=repo.id,
        version=tag, lifecycle_state="AVAILABLE",
    )
    for image in summaries:
        # The API version filter matches version strings; reject wildcard-like matches.
        detail = client.get_container_image(image.id).data
        matches = [v for v in (detail.versions or []) if v.version == tag]
        if matches:
            version = matches[0]
            return ImageChoice(tag=tag, digest=image.digest,
                               pushed_at=version.time_created,
                               size_bytes=getattr(detail, "layers_size_in_bytes", 0) or 0)
        if image.version == tag:
            return ImageChoice(tag=tag, digest=image.digest,
                               pushed_at=image.time_created,
                               size_bytes=getattr(detail, "layers_size_in_bytes", 0) or 0)
    raise ValueError(f"OCIR image tag '{tag}' was not found in {repo.display_name}")


def image_uri(region: str, namespace: str, repository: str, digest: str, registry_host: str | None = None) -> str:
    host = registry_host or f"{region}.ocir.io"
    return f"{host}/{namespace}/{repository}@{digest}"
