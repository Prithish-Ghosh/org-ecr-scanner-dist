"""Interactive multi-repository scanner for AWS ECR and Oracle Cloud OCIR."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import getpass
import json
import os
from pathlib import Path
import re
import shutil
import sys

from botocore.exceptions import BotoCoreError, ClientError, NoCredentialsError, ProfileNotFound

from . import __version__
from .aws_ecr import available_profiles, get_repository, list_recent_images, list_repositories, resolve_tag, session_for
from .batch_report import generate_batch_pdf
from .reporter import generate_pdf
from .trivy_runner import run_scan, run_ocir_scan


def ask_choice(question: str, items: list[str], show_max: int = 30, manual_allowed: bool = False) -> str:
    if not items and not manual_allowed:
        raise RuntimeError(f"No options available for {question}")
    print(f"\n{question}")
    for i, value in enumerate(items[:show_max], 1):
        print(f" {i:>3}. {value}")
    if len(items) > show_max:
        print(f" ... {len(items)-show_max} more; enter exact name to select a hidden item")
    while True:
        text = input("Enter number or name [1]: ").strip()
        if not text and items:
            return items[0]
        if text.isdigit() and 1 <= int(text) <= len(items):
            return items[int(text)-1]
        if text in items or (manual_allowed and text):
            return text
        print("Invalid choice; enter a listed number or full name")


def parse_selection(value: str, names: list[str]) -> list[str]:
    """Accept `1,2,5-7`, `all`, and comma-separated exact repository names."""
    raw = value.strip()
    if raw.lower() in ("all", "*"):
        return names.copy()
    chosen: list[str] = []
    for part in raw.split(","):
        token = part.strip()
        if not token:
            raise ValueError("Empty item in repository selection")
        if re.fullmatch(r"\d+\s*-\s*\d+", token):
            start, end = map(int, re.split(r"\s*-\s*", token))
            if start < 1 or end > len(names) or start > end:
                raise ValueError(f"Invalid range {token} (valid 1-{len(names)})")
            matches = names[start-1:end]
        elif token.isdigit():
            i = int(token)
            if i < 1 or i > len(names):
                raise ValueError(f"Invalid repository number {i} (valid 1-{len(names)})")
            matches = [names[i-1]]
        elif token in names:
            matches = [token]
        else:
            raise ValueError(f"Unknown repository '{token}'")
        for repo in matches:
            if repo not in chosen:
                chosen.append(repo)
    if not chosen:
        raise ValueError("Select at least one repository")
    return chosen


def ask_repositories(names: list[str]) -> list[str]:
    if not names:
        raise ValueError("No repositories found. Check region, compartment and IAM policies")
    print("\nSelect repositories to scan:")
    for i, name in enumerate(names, 1):
        print(f" {i:>3}. {name}")
    print("You can type: 1,3,5-7  |  all  |  repository-name")
    while True:
        raw = input("Repositories [1]: ").strip() or "1"
        try:
            return parse_selection(raw, names)
        except ValueError as exc:
            print(f"Invalid selection: {exc}")


def slug(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_.-]", "_", value)[:90].strip("._-") or "unknown"


def output_folder(parent: Path, repository: str, tag: str) -> Path:
    suffix = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    folder = parent / f"{slug(repository)}_{slug(tag)}_{suffix}"
    folder.mkdir(parents=True, exist_ok=False)
    return folder


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="scan", description="Multi-repo AWS ECR / Oracle OCIR Trivy image assessment with beautiful PDF reports",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--provider", choices=["ecr", "ocir"], help="Cloud registry; prompted when run interactively")
    p.add_argument("--profile", help="AWS named profile for ECR (legacy flag)")
    p.add_argument("--region", help="Cloud region, e.g. ap-south-1 or me-jeddah-1")
    p.add_argument("--repository", "--repositories", dest="repositories", action="append", metavar="NAME[,NAME...]",
                   help="One or more repository names. Repeat flag or use comma-separated names")
    tag_args = p.add_mutually_exclusive_group()
    tag_args.add_argument("--tag", help="Use this image tag for each repository (unless --repo-tag overrides)")
    tag_args.add_argument("--latest", action="store_true", help="Scan the latest pushed tagged image from every selected repo")
    p.add_argument("--repo-tag", action="append", metavar="REPOSITORY=TAG",
                   help="Per-repository image tag; repeat for several repositories")
    p.add_argument("--oci-profile", help="OCI SDK config profile (default DEFAULT)")
    p.add_argument("--oci-compartment", help="OCI compartment OCID; defaults to tenancy root with subtree listing")
    p.add_argument("--oci-namespace", help="OCIR namespace; auto-detected from OCI Object Storage if omitted")
    p.add_argument("--ocir-host", help="OCIR registry hostname override, e.g. jed.ocir.io")
    p.add_argument("--output-dir", type=Path, default=Path.cwd() / "scan-reports", help="Report parent directory")
    p.add_argument("--scanners", choices=["vuln", "vuln,secret"], default="vuln", help="Trivy scanners")
    p.add_argument("--fail-on", choices=["none", "CRITICAL", "HIGH", "MEDIUM", "LOW"], default="none",
                   help="CI: return exit code 2 if severity meets/exceeds threshold")
    p.add_argument("--non-interactive", action="store_true", help="Fail rather than prompt (CI mode)")
    p.add_argument("--from-json", type=Path, help="Produce a PDF from an existing Trivy JSON file without scanning")
    p.add_argument("--image", help="Image label for --from-json")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return p


def policy_failed(counts: dict[str,int], level: str) -> bool:
    if level == "none":
        return False
    levels = ["CRITICAL", "HIGH", "MEDIUM", "LOW"]
    return any(counts.get(s, 0) for s in levels[:levels.index(level)+1])


def _tag_map(pairs: list[str] | None) -> dict[str, str]:
    out = {}
    for pair in pairs or []:
        if "=" not in pair:
            raise ValueError(f"--repo-tag requires REPOSITORY=TAG, received {pair}")
        repo, tag = pair.rsplit("=", 1)
        if not repo.strip() or not tag.strip():
            raise ValueError(f"Invalid --repo-tag {pair}")
        out[repo.strip()] = tag.strip()
    return out


def requested_repositories(args, known: list[str], interactive: bool) -> list[str]:
    if args.repositories:
        chunks = []
        for value in args.repositories:
            chunks.extend(part.strip() for part in value.split(","))
        if not all(chunks):
            raise ValueError("Empty repository name in --repository")
        # Names can be supplied even if list permission is unavailable. Real get by name validates later.
        return list(dict.fromkeys(chunks))
    if not interactive:
        raise ValueError("--repository is required with --non-interactive")
    return ask_repositories(known)


def choose_tag(repo: str, args, tags: dict[str, str], interactive: bool, loader) -> str:
    if repo in tags:
        return tags[repo]
    if args.tag:
        return args.tag
    if args.latest or interactive:
        recent = loader()
        if not recent:
            raise ValueError(f"Repository {repo} has no tagged images")
        if args.latest:
            print(f"{repo}: latest pushed tag is {recent[0].tag}")
            return recent[0].tag
        labels = [f"{i.tag} | pushed {i.pushed_at:%Y-%m-%d %H:%M UTC}" if i.pushed_at else i.tag
                  for i in recent]
        choice = ask_choice(f"Image tag for {repo} (newest first)", labels,
                            show_max=30, manual_allowed=True)
        return recent[labels.index(choice)].tag if choice in labels else choice
    raise ValueError(f"Specify --tag, --latest or --repo-tag {repo}=TAG in CI mode")


def save_report(folder: Path, data: dict, meta: dict) -> dict:
    destination = folder / "vulnerability-report.pdf"
    result = generate_pdf(data, destination, meta)
    (folder / "scan-metadata.json").write_text(json.dumps(meta, indent=2, default=str), encoding="utf-8")
    return result


def _offline(args) -> int:
    source = args.from_json.expanduser().resolve()
    with source.open("r", encoding="utf-8") as fh:
        data = json.load(fh)
    if not isinstance(data, dict) or not isinstance(data.get("Results", []), list) or not ("SchemaVersion" in data or "Results" in data):
        raise ValueError("Expected valid Trivy JSON with Results or SchemaVersion")
    image = args.image or data.get("ArtifactName", "offline-scan")
    folder = output_folder(args.output_dir, image, "offline")
    shutil.copyfile(source, folder / "trivy-results.json")
    meta = {"provider": "offline", "image_uri": image, "repository": image,
            "tag": "offline JSON import", "region": "N/A", "profile": "offline",
            "digest": data.get("Metadata", {}).get("ImageID", "not provided"),
            "trivy_version": "imported scan (unverified)", "scanners": "from existing JSON",
            "scanned_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    result = save_report(folder, data, meta)
    print(f"PDF: {folder / 'vulnerability-report.pdf'}")
    print(f"Findings: {result['total']}")
    return 2 if policy_failed(result["counts"], args.fail_on) else 0


def _aws_backend(args, interactive: bool):
    profile = args.profile
    if interactive and not profile:
        profile = ask_choice("AWS profile", available_profiles())
    if profile == "default":
        profile = None
    base = session_for(profile, args.region)
    region = args.region or base.region_name
    if not region and interactive:
        region = input("AWS ECR region [ap-south-1]: ").strip() or "ap-south-1"
    if not region:
        raise ValueError("Supply AWS --region or configure a region in your profile")
    session = session_for(profile, region)
    account_id = session.client("sts").get_caller_identity()["Account"]
    ecr = session.client("ecr")
    print(f"ECR account {account_id} | profile {profile or 'default'} | region {region}")
    known = [] if args.repositories else [repo["repositoryName"] for repo in list_repositories(ecr)]
    selected = requested_repositories(args, known, interactive)

    def scan_one(name: str, tag: str, folder: Path):
        repository = get_repository(ecr, name)
        if str(repository.get("registryId")) != str(account_id):
            raise RuntimeError("The configured AWS credentials cannot access this account's registry")
        image = resolve_tag(ecr, name, tag)
        uri = f"{repository['repositoryUri']}@{image.digest}"
        target = folder / "trivy-results.json"
        version = run_scan(ecr, uri, target, args.scanners)
        meta = {"provider": "ecr", "account_id": account_id, "profile": profile or "default",
                "region": region, "repository": name, "tag": image.tag, "digest": image.digest,
                "image_uri": uri, "trivy_version": version, "scanners": args.scanners,
                "scanned_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
        return target, meta

    def tags_for(name: str):
        return list_recent_images(ecr, name)

    return selected, scan_one, tags_for


def _oci_backend(args, interactive: bool):
    from . import ocir
    profile = args.oci_profile
    if interactive and not profile:
        profile = ask_choice("OCI profile (~/.oci/config)", ocir.profiles())
    profile = profile or "DEFAULT"
    client, config = ocir.client_for(profile, args.region)
    region = config["region"]
    compartment = args.oci_compartment or config["tenancy"]
    root = compartment == config["tenancy"]
    namespace = args.oci_namespace or ocir.registry_namespace(config)
    if "/" in namespace or not namespace:
        raise ValueError("Invalid OCI tenancy namespace")
    host = args.ocir_host or f"{region}.ocir.io"
    if not re.fullmatch(r"[A-Za-z0-9.-]+", host):
        raise ValueError("--ocir-host must be a hostname without scheme/path")
    print(f"OCIR profile {profile} | region {region} | namespace {namespace} | compartment {compartment}")
    all_repos = ocir.list_repositories(client, compartment, subtree=root)
    by_name = {r.display_name: r for r in all_repos}
    selected = requested_repositories(args, list(by_name), interactive)
    for name in selected:
        if name not in by_name:
            raise ValueError(f"OCIR repository '{name}' not available in selected compartment/subtree")
    # OCI SDK config/API key is NOT a private-registry pull token.
    username = os.environ.get("OCI_OCIR_USERNAME", "").strip()
    token = os.environ.get("OCI_OCIR_AUTH_TOKEN", "")
    if not (username and token) and interactive:
        username = username or input("OCIR login username (namespace/username): ").strip()
        token = token or getpass.getpass("OCIR auth token (hidden): ")
    if not username or not token:
        raise ValueError("OCIR requires OCI_OCIR_USERNAME and OCI_OCIR_AUTH_TOKEN environment variables (not your OCI API key)")
    if not username.startswith(namespace + "/"):
        raise ValueError(f"OCIR username must begin with the namespace '{namespace}/'")

    def scan_one(name: str, tag: str, folder: Path):
        repo = by_name[name]
        image = ocir.resolve_tag(client, repo, tag)
        uri = ocir.image_uri(region, namespace, name, image.digest, host)
        target = folder / "trivy-results.json"
        version = run_ocir_scan(uri, target, args.scanners, username, token)
        meta = {"provider": "ocir", "namespace": namespace, "profile": profile,
                "region": region, "compartment_id": repo.compartment_id,
                "repository": name, "tag": image.tag, "digest": image.digest,
                "image_uri": uri, "trivy_version": version, "scanners": args.scanners,
                "scanned_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
        return target, meta

    def tags_for(name: str):
        return ocir.list_recent_images(client, by_name[name])

    return selected, scan_one, tags_for


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        print("\nORG CLOUD TRIVY SCANNER  |  ECR + OCIR  |  v" + __version__ + "\n")
        if args.from_json:
            return _offline(args)
        interactive = not args.non_interactive and sys.stdin.isatty()
        provider = args.provider
        if not provider and interactive:
            selected = ask_choice("Select registry provider", ["AWS ECR", "Oracle OCIR"])
            provider = "ecr" if selected == "AWS ECR" else "ocir"
        provider = provider or "ecr"  # backward compatible for old AWS pipelines
        tag_map = _tag_map(args.repo_tag)
        if provider == "ecr":
            selected, do_scan, fetch_tags = _aws_backend(args, interactive)
        else:
            selected, do_scan, fetch_tags = _oci_backend(args, interactive)
        batch = []
        run_dir = args.output_dir / ("batch_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"))
        run_dir.mkdir(parents=True, exist_ok=True)
        for i, repo in enumerate(selected, 1):
            print(f"\n[{i}/{len(selected)}] Repository: {repo}")
            item = {"provider": provider, "repository": repo, "tag": "-", "status": "failed"}
            try:
                tag = choose_tag(repo, args, tag_map, interactive, lambda repo=repo: fetch_tags(repo))
                item["tag"] = tag
                folder = output_folder(run_dir, repo, tag)
                target, meta = do_scan(repo, tag, folder)
                with target.open("r", encoding="utf-8") as fh:
                    result = save_report(folder, json.load(fh), meta)
                item.update({"status": "success", "counts": result["counts"],
                             "total": result["total"], "secrets": result["secrets"],
                             "pdf": str(folder / "vulnerability-report.pdf"),
                             "json": str(target), "metadata": str(folder / "scan-metadata.json")})
                print(f"  PASS: {repo}:{tag} | Findings {result['total']} | PDF: {item['pdf']}")
            except (Exception, KeyboardInterrupt) as exc:
                if isinstance(exc, KeyboardInterrupt):
                    raise
                item["error"] = str(exc)
                print(f"  FAILED {repo}: {exc}", file=sys.stderr)
            batch.append(item)
        summary_path = run_dir / "batch-summary.json"
        summary_path.write_text(json.dumps(batch, indent=2), encoding="utf-8")
        pdf_path = run_dir / "batch-vulnerability-report.pdf"
        generate_batch_pdf(batch, pdf_path)
        print(f"\nBatch summary: {summary_path.resolve()}")
        if pdf_path.is_file():
            print(f"Consolidated PDF: {pdf_path.resolve()}")
        failures = [item for item in batch if item["status"] != "success"]
        violating = [item for item in batch if item["status"] == "success" and policy_failed(item["counts"], args.fail_on)]
        print(f"Completed {len(batch)-len(failures)}/{len(batch)} scans | failed={len(failures)} | policy violations={len(violating)}")
        if failures:
            return 1
        if violating:
            return 2
        return 0
    except (ClientError, BotoCoreError, NoCredentialsError, ProfileNotFound) as exc:
        print(f"AWS error: {exc}. Verify profile, region, permissions and SSO login.", file=sys.stderr)
        return 1
    except (ValueError, RuntimeError, OSError, KeyboardInterrupt, json.JSONDecodeError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        # Handles OCI SDK ServiceError and other unexpected provider failures.
        print(f"Cloud provider error ({type(exc).__name__}): {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
