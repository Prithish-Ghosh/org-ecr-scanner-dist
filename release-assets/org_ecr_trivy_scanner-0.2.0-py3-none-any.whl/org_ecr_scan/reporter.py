"""Attractive, readable, paginated Trivy JSON security reports (ReportLab)."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from html import escape
from pathlib import Path
from urllib.parse import urlparse

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    Flowable, HRFlowable, KeepTogether, LongTable, PageBreak, Paragraph,
    SimpleDocTemplate, Spacer, Table, TableStyle,
)

NAVY = colors.HexColor("#142039")
MIDNIGHT = colors.HexColor("#0B1426")
TEAL = colors.HexColor("#00AE9A")
BLUE = colors.HexColor("#4D81F2")
SLATE = colors.HexColor("#53617B")
LIGHT = colors.HexColor("#F3F6FA")
WHITE = colors.white
RED = colors.HexColor("#E34B5C")
ORANGE = colors.HexColor("#F28B50")
YELLOW = colors.HexColor("#C89925")
GREY = colors.HexColor("#94A1B7")
SEV_COLORS = {"CRITICAL": RED, "HIGH": ORANGE, "MEDIUM": YELLOW, "LOW": BLUE, "UNKNOWN": GREY}
SEVERITIES = ("CRITICAL", "HIGH", "MEDIUM", "LOW", "UNKNOWN")


def safe(value: object) -> str:
    return escape(str(value if value is not None else "-"), quote=True)


def one_line(value: object) -> str:
    return " ".join(str(value or "-").split())


def summary(data: dict) -> dict:
    vulnerabilities = []
    secrets = []
    for result in data.get("Results") or []:
        target = result.get("Target", "Unknown target")
        category = result.get("Class", "")
        for vuln in result.get("Vulnerabilities") or []:
            vulnerabilities.append({**vuln, "Target": target, "Class": category})
        for secret in result.get("Secrets") or []:
            # Deliberately avoid preserving Matches / Code in report records.
            secrets.append({
                "Target": target,
                "RuleID": secret.get("RuleID", "-"),
                "Title": secret.get("Title", "Secret exposed"),
                "Severity": secret.get("Severity", "UNKNOWN"),
                "StartLine": secret.get("StartLine", "-"),
            })
    counts = Counter(v.get("Severity", "UNKNOWN").upper() for v in vulnerabilities)
    for sev in SEVERITIES:
        counts.setdefault(sev, 0)
    vulnerabilities.sort(key=lambda v: (
        SEVERITIES.index(v.get("Severity", "UNKNOWN").upper())
        if v.get("Severity", "UNKNOWN").upper() in SEVERITIES else len(SEVERITIES),
        v.get("Target", ""), v.get("VulnerabilityID", ""),
    ))
    return {"vulnerabilities": vulnerabilities, "secrets": secrets,
            "counts": counts, "total": len(vulnerabilities)}


class CoverBanner(Flowable):
    def __init__(self, width: float, title: str, subtitle: str, is_demo: bool = False):
        super().__init__()
        self.width, self.height = width, 155
        self.title, self.subtitle, self.is_demo = title, subtitle, is_demo

    def draw(self):
        c = self.canv
        c.setFillColor(NAVY)
        c.roundRect(0, 0, self.width, self.height, 14, fill=1, stroke=0)
        c.setFillColor(TEAL)
        c.roundRect(25, self.height - 38, 80, 4, 2, fill=1, stroke=0)
        c.setFont("Helvetica-Bold", 10)
        c.setFillColor(colors.HexColor("#79EBD8"))
        c.drawString(26, self.height - 57, "INFRASTRUCTURE SECURITY  /  AUTOMATED ASSESSMENT")
        c.setFillColor(WHITE)
        c.setFont("Helvetica-Bold", 25)
        c.drawString(25, self.height - 93, "CONTAINER IMAGE")
        c.drawString(25, self.height - 124, "SECURITY REPORT")
        c.setStrokeColor(colors.HexColor("#263D5B"))
        c.setLineWidth(1)
        c.line(self.width - 100, 25, self.width - 26, 25)
        c.setFillColor(colors.HexColor("#223650"))
        c.circle(self.width - 53, self.height - 48, 22, fill=1, stroke=0)
        c.setFillColor(TEAL)
        c.setFont("Helvetica-Bold", 19)
        c.drawCentredString(self.width - 53, self.height - 55, "S")
        if self.is_demo:
            c.setFillColor(colors.HexColor("#FFCCA8"))
            c.setFont("Helvetica-Bold", 8)
            c.drawRightString(self.width - 26, 11, "DEMONSTRATION - SYNTHETIC DATA")


class SeverityBars(Flowable):
    def __init__(self, width: float, counts: Counter):
        super().__init__()
        self.width, self.height = width, 135
        self.counts = counts

    def draw(self):
        c = self.canv
        longest = max([self.counts.get(s, 0) for s in SEVERITIES] + [1])
        for i, severity in enumerate(SEVERITIES):
            y = self.height - 14 - i * 25
            val = self.counts.get(severity, 0)
            c.setFillColor(NAVY)
            c.setFont("Helvetica-Bold", 9)
            c.drawString(0, y, severity)
            x = 84
            available = self.width - 125
            c.setFillColor(LIGHT)
            c.roundRect(x, y - 1, available, 12, 5, fill=1, stroke=0)
            if val:
                c.setFillColor(SEV_COLORS[severity])
                c.roundRect(x, y - 1, max(5, available * val / longest), 12, 5, fill=1, stroke=0)
            c.setFillColor(NAVY)
            c.setFont("Helvetica-Bold", 10)
            c.drawRightString(self.width, y, f"{val:,}")


def styles_for_pdf():
    base = getSampleStyleSheet()
    return {
        "subtitle": ParagraphStyle("SubT", parent=base["Normal"], fontName="Helvetica",
                                   fontSize=11, leading=17, textColor=SLATE, spaceAfter=8),
        "section": ParagraphStyle("Sec", parent=base["Heading2"], fontName="Helvetica-Bold",
                                  fontSize=16, leading=20, textColor=NAVY, spaceBefore=16, spaceAfter=9),
        "h3": ParagraphStyle("H3", parent=base["Heading3"], fontName="Helvetica-Bold",
                             fontSize=10, leading=14, textColor=NAVY, spaceBefore=8, spaceAfter=5, keepWithNext=True),
        "body": ParagraphStyle("BodyC", parent=base["Normal"], fontName="Helvetica",
                               fontSize=9, leading=14, textColor=SLATE, spaceAfter=7, splitLongWords=True),
        "fine": ParagraphStyle("Fine", parent=base["Normal"], fontName="Helvetica",
                               fontSize=7.1, leading=10.5, textColor=NAVY, splitLongWords=True),
        "small": ParagraphStyle("SmallC", parent=base["Normal"], fontName="Helvetica",
                                fontSize=8.3, leading=12, textColor=SLATE, splitLongWords=True),
        "white": ParagraphStyle("White", parent=base["Normal"], fontName="Helvetica-Bold",
                                fontSize=9, leading=11, textColor=WHITE),
        "number": ParagraphStyle("Number", parent=base["Normal"], fontName="Helvetica-Bold",
                                 fontSize=20, leading=23, textColor=NAVY, alignment=TA_CENTER),
        "kpi": ParagraphStyle("Kpi", parent=base["Normal"], fontName="Helvetica",
                              fontSize=8, leading=11, textColor=SLATE, alignment=TA_CENTER),
    }


def metadata_table(meta: dict, st: dict, width: float):
    fields = [
        ("Provider", meta.get("provider", "ECR").upper()),
        ("Account / namespace", meta.get("account_id", meta.get("namespace", "not supplied"))),
        ("Cloud profile", meta.get("profile", "default")),
        ("Region", meta.get("region", "-")),
        ("Repository", meta.get("repository", "-")),
        ("Requested tag", meta.get("tag", "-")),
        ("Image digest", meta.get("digest", "-")),
        ("Scanned at (UTC)", meta.get("scanned_at", datetime.now(timezone.utc).isoformat())),
        ("Trivy version", meta.get("trivy_version", "not provided")),
        ("Image URI", meta.get("image_uri", "-")),
        ("Scanners", meta.get("scanners", "vuln")),
    ]
    rows = [[Paragraph(safe(k), st["small"]), Paragraph(safe(v), st["small"])] for k, v in fields]
    t = Table(rows, colWidths=[108, width - 108], hAlign="LEFT")
    t.setStyle(TableStyle([
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [WHITE, LIGHT]),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 11),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ("LINEBELOW", (0, -1), (-1, -1), 0.5, colors.HexColor("#DCE4EE")),
    ]))
    return t


def score(vuln: dict) -> str:
    numeric = []
    for score_from in (vuln.get("CVSS") or {}).values():
        if isinstance(score_from, dict):
            for key in ("V4Score", "V3Score", "V2Score"):
                try:
                    if score_from.get(key) is not None:
                        numeric.append(float(score_from[key]))
                except (ValueError, TypeError):
                    pass
    return f"{max(numeric):.1f}" if numeric else "-"


def _link(vuln: dict) -> str | None:
    candidates = [vuln.get("PrimaryURL"), *(vuln.get("References") or [])]
    for candidate in candidates:
        if isinstance(candidate, str) and urlparse(candidate).scheme in ("http", "https"):
            return candidate
    return None


def _vuln_rows(vulns: list[dict], st: dict):
    rows = [[Paragraph(x, st["white"]) for x in
             ("VULNERABILITY / TARGET", "PACKAGE / FIX", "DETAILS")]]
    for v in vulns:
        severity = one_line(v.get("Severity", "UNKNOWN")).upper()
        identifier = one_line(v.get("VulnerabilityID", "Unknown ID"))
        url = _link(v)
        if url:
            identifier_html = f'<link href="{safe(url)}" color="#277ED2"><u>{safe(identifier)}</u></link>'
        else:
            identifier_html = safe(identifier)
        heading = (f'<font color="{"#%02X%02X%02X" % (int(SEV_COLORS.get(severity, GREY).red * 255), int(SEV_COLORS.get(severity, GREY).green * 255), int(SEV_COLORS.get(severity, GREY).blue * 255))}"><b>{safe(severity)}</b></font>'
                   f'<br/>{identifier_html}<br/><font color="#65738B">{safe(v.get("Target", "-"))}</font>')
        pkg = (f'<b>{safe(v.get("PkgName", "-"))}</b><br/>'
               f'Installed: {safe(v.get("InstalledVersion", "-"))}<br/>'
               f'Fix: <font color="#007D6D">{safe(v.get("FixedVersion") or "Not available")}</font>')
        detail = (f'<b>{safe(v.get("Title") or v.get("VulnerabilityID") or "Vulnerability")}</b><br/>'
                  f'CVSS (max): {safe(score(v))}  |  Status: {safe(v.get("Status", "not stated"))}'
                  f'<br/>{safe(one_line(v.get("Description", "No description supplied"))[:520])}')
        rows.append([Paragraph(heading, st["fine"]), Paragraph(pkg, st["fine"]),
                     Paragraph(detail, st["fine"])])
    return rows


def footer(canvas, doc):
    canvas.saveState()
    w, h = A4
    canvas.setStrokeColor(colors.HexColor("#D9E3EE"))
    canvas.setLineWidth(0.6)
    canvas.line(18 * mm, 19 * mm, w - 18 * mm, 19 * mm)
    canvas.setFillColor(SLATE)
    canvas.setFont("Helvetica", 8)
    canvas.drawString(18 * mm, 13.5 * mm, "ORG CLOUD TRIVY SCANNER  |  Security assessment")
    canvas.drawRightString(w - 18 * mm, 13.5 * mm, f"Page {doc.page}")
    canvas.restoreState()


def generate_pdf(report: dict, destination: Path, meta: dict) -> dict:
    """Render a self-contained PDF including every vulnerability row."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    stats = summary(report)
    st = styles_for_pdf()
    page_w, page_h = A4
    doc = SimpleDocTemplate(str(destination), pagesize=A4, leftMargin=18 * mm,
                            rightMargin=18 * mm, topMargin=19 * mm, bottomMargin=26 * mm,
                            title="Container Image Vulnerability Assessment",
                            author="Org ECR Trivy Scanner")
    width = page_w - 36 * mm
    story = [CoverBanner(width, "CONTAINER IMAGE", "SECURITY REPORT",
                         is_demo="DEMO ONLY" in str(meta.get("image_uri", ""))), Spacer(1, 15)]
    story.append(Paragraph("Executive overview", st["section"]))
    story.append(Paragraph(
        "Automated image assessment using Trivy. Findings are reported as detected; no vulnerabilities "
        "are silently removed or marked remediated. A full machine-readable JSON scan is produced alongside this PDF.",
        st["body"],
    ))
    total = stats["total"]
    cards = []
    for count, label in ((total, "TOTAL FINDINGS"),
                         (stats["counts"]["CRITICAL"], "CRITICAL"),
                         (stats["counts"]["HIGH"], "HIGH"),
                         (stats["counts"]["MEDIUM"], "MEDIUM")):
        cards.append(Table([[Paragraph(str(count), st["number"])], [Paragraph(label, st["kpi"])]],
                           colWidths=[(width - 24) / 4], style=TableStyle([
                               ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
                               ("TOPPADDING", (0, 0), (-1, 0), 12),
                               ("BOTTOMPADDING", (0, -1), (-1, -1), 12),
                           ])))
    grid = Table([cards], colWidths=[width / 4] * 4,
                 style=TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                                   ("LEFTPADDING", (0, 0), (-1, -1), 0),
                                   ("RIGHTPADDING", (0, 0), (-1, -1), 6)]))
    story.extend([grid, Spacer(1, 12), Paragraph("Severity distribution", st["section"]),
                  SeverityBars(width, stats["counts"]), Spacer(1, 11)])
    if stats["secrets"]:
        story.append(Paragraph(f"<b>{len(stats['secrets'])} secret detections</b> are listed in the appendix "
                               "without printing exposed credential values.", st["body"]))
    story.append(PageBreak())
    story.append(Paragraph("Scan provenance", st["section"]))
    story.append(metadata_table(meta, st, width))
    story.append(Spacer(1, 8))
    story.append(Paragraph("How to interpret the results", st["section"]))
    story.append(Paragraph(
        "Counts describe vulnerability occurrences across scanned targets, not necessarily distinct CVE identifiers. "
        "A listed fixed version is vendor advisory metadata, not proof that the application is patched. "
        "An empty finding list is not a guarantee that the image is free of vulnerabilities. "
        "Prioritize critical/high items, confirm applicability and validate fixes with a new image scan.", st["body"],
    ))

    story.append(Spacer(1, 7))
    story.append(Paragraph("Vulnerability findings", st["section"]))
    if not stats["vulnerabilities"]:
        story.append(Paragraph("Trivy did not report known vulnerabilities for this scan's settings and database.", st["body"]))
    else:
        for severity in SEVERITIES:
            items = [v for v in stats["vulnerabilities"] if v.get("Severity", "UNKNOWN").upper() == severity]
            if not items:
                continue
            story.append(Paragraph(f"{severity}  |  {len(items):,} findings", st["h3"]))
            rows = _vuln_rows(items, st)
            table = LongTable(rows, colWidths=[width * .245, width * .25, width * .505],
                              repeatRows=1, hAlign="LEFT", splitByRow=1)
            table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), NAVY),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, LIGHT]),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("TOPPADDING", (0, 0), (-1, 0), 10),
                ("BOTTOMPADDING", (0, 0), (-1, 0), 10),
                ("TOPPADDING", (0, 1), (-1, -1), 8),
                ("BOTTOMPADDING", (0, 1), (-1, -1), 8),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("LINEBELOW", (0, 1), (-1, -1), 0.3, colors.HexColor("#E0E7EF")),
            ]))
            story.extend([table, Spacer(1, 14)])

    if stats["secrets"]:
        story.append(PageBreak())
        story.append(Paragraph("Secret detections (redacted)", st["section"]))
        story.append(Paragraph(
            "Only the type, severity and location of detections appear here. Secret contents "
            "and matching source lines are intentionally omitted; treat scan JSON as sensitive.", st["body"],
        ))
        secret_rows = [[Paragraph(x, st["white"]) for x in ("SEVERITY", "RULE / FINDING", "LOCATION")]]
        for item in stats["secrets"]:
            secret_rows.append([
                Paragraph(safe(item["Severity"]), st["fine"]),
                Paragraph(f'<b>{safe(item["RuleID"])}</b><br/>{safe(item["Title"])}', st["fine"]),
                Paragraph(f'{safe(item["Target"])}<br/>Line: {safe(item["StartLine"])}', st["fine"]),
            ])
        table = LongTable(secret_rows, colWidths=[width * .15, width * .37, width * .48],
                          repeatRows=1, splitByRow=1)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), NAVY),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, LIGHT]),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ]))
        story.append(table)
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return {"counts": dict(stats["counts"]), "total": total,
            "secrets": len(stats["secrets"]), "pdf": str(destination)}
