"""Organization multi-cloud container image security scanner."""
__version__ = "0.2.0"
