"""Trivy execution with short-lived, isolated registry credentials."""
from __future__ import annotations

import base64
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from urllib.parse import urlparse


def require_trivy() -> str:
    binary = shutil.which("trivy")
    if not binary:
        raise RuntimeError("Trivy executable not found on PATH. Install: https://trivy.dev/latest/getting-started/installation/")
    return binary


def trivy_version(binary: str) -> str:
    try:
        response = subprocess.run([binary, "--version"], capture_output=True, text=True, timeout=15)
        return (response.stdout.strip().splitlines() or ["unknown"])[0]
    except (OSError, subprocess.TimeoutExpired):
        return "unknown"


def scan_with_registry_login(image_uri: str, report_json: Path, scanners: str,
                             registry: str, username: str, password: str) -> str:
    """Login via stdin, scan by digest, and remove registry secrets on exit.

    Credentials are scoped to a private temporary Docker config per scan. No
    password is ever included in the process command line or saved in reports.
    """
    binary = require_trivy()
    if not username or not password:
        raise RuntimeError("Registry username/auth token is missing")
    if image_uri.split("/", 1)[0] != registry:
        raise ValueError("Image registry does not match authentication target")
    with tempfile.TemporaryDirectory(prefix="org-cloud-trivy-") as docker_config:
        env = os.environ.copy()
        env["DOCKER_CONFIG"] = docker_config
        # Avoid leaking cross-registry credentials from the surrounding environment.
        env.pop("TRIVY_USERNAME", None)
        env.pop("TRIVY_PASSWORD", None)
        env.pop("TRIVY_REGISTRY_TOKEN", None)
        env.pop("OCI_OCIR_AUTH_TOKEN", None)
        env.pop("OCI_OCIR_USERNAME", None)
        login = subprocess.run(
            [binary, "registry", "login", "--username", username, "--password-stdin", registry],
            input=password, capture_output=True, text=True, env=env, timeout=60,
        )
        if login.returncode != 0:
            # Do not display subprocess stderr; it might echo sensitive credentials.
            raise RuntimeError(f"Trivy registry login failed for {registry} (code {login.returncode})")
        command = [
            binary, "image", "--image-src", "remote", "--scanners", scanners,
            "--format", "json", "--exit-code", "0", "--output", str(report_json),
            image_uri,
        ]
        print(f"Scanning {image_uri} (Trivy vulnerability DB may download on first run)...", flush=True)
        result = subprocess.run(command, env=env)
        if result.returncode != 0:
            raise RuntimeError(f"Trivy scan failed with exit code {result.returncode}; results cannot be trusted")
        if not report_json.is_file():
            raise RuntimeError("Trivy exited successfully but no JSON output was created")
        with report_json.open(encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, dict) or not isinstance(data.get("Results", []), list) or not ("SchemaVersion" in data or "Results" in data):
            raise RuntimeError("Trivy output is not a recognized JSON report")
    return trivy_version(binary)


def run_scan(ecr, image_uri: str, report_json: Path, scanners: str) -> str:
    """Legacy AWS ECR entry point, retained for backwards compatibility."""
    auths = ecr.get_authorization_token().get("authorizationData", [])
    registry = image_uri.split("/", 1)[0]
    for entry in auths:
        host = urlparse(entry.get("proxyEndpoint", "")).netloc
        if host != registry:
            continue
        username, separator, password = base64.b64decode(entry["authorizationToken"]).decode().partition(":")
        if separator and username and password:
            return scan_with_registry_login(image_uri, report_json, scanners, registry, username, password)
    raise RuntimeError(f"ECR did not return a valid authentication token for {registry}")


def run_ocir_scan(image_uri: str, report_json: Path, scanners: str, username: str, auth_token: str) -> str:
    return scan_with_registry_login(image_uri, report_json, scanners, image_uri.split("/", 1)[0], username, auth_token)
